"use client"

import * as React from "react"
import { ProjectCard } from "@/components/ui/ProjectCard"
import { Button } from "@/components/ui/button"
import { projects } from "@/data/projects"

const categories = ["All", "Full Stack", "Frontend", "Backend", "AI/ML"]

export function Projects() {
    const [selectedCategory, setSelectedCategory] = React.useState("All")

    const filteredProjects = projects.filter(
        (project) => selectedCategory === "All" || project.category === selectedCategory
    )

    return (
        <section id="projects" className="py-20 bg-muted/30">
            <div className="container mx-auto px-4">
                <div className="flex flex-col items-center mb-12">
                    <h2 className="text-3xl font-bold tracking-tight mb-4">Featured Projects</h2>
                    <div className="w-20 h-1 bg-primary rounded-full mb-8" />

                    <div className="flex flex-wrap justify-center gap-2">
                        {categories.map((category) => (
                            <Button
                                key={category}
                                variant={selectedCategory === category ? "default" : "outline"}
                                onClick={() => setSelectedCategory(category)}
                                className="rounded-full"
                            >
                                {category}
                            </Button>
                        ))}
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredProjects.map((project) => (
                        <ProjectCard key={project.id} project={project} />
                    ))}
                </div>
            </div>
        </section>
    )
}
