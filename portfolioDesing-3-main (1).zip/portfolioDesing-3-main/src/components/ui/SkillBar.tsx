"use client"

import * as React from "react"
import { motion } from "framer-motion"

interface SkillBarProps {
    name: string
    level: number
    icon?: string
}

export function SkillBar({ name, level }: SkillBarProps) {
    return (
        <div className="mb-4">
            <div className="flex justify-between mb-1">
                <span className="text-sm font-medium">{name}</span>
                <span className="text-sm font-medium text-muted-foreground">{level}%</span>
            </div>
            <div className="h-2.5 w-full rounded-full bg-secondary">
                <motion.div
                    className="h-2.5 rounded-full bg-primary"
                    initial={{ width: 0 }}
                    whileInView={{ width: `${level}%` }}
                    transition={{ duration: 1, ease: "easeOut" }}
                    viewport={{ once: true }}
                />
            </div>
        </div>
    )
}
