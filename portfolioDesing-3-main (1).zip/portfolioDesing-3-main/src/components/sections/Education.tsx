"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const education = [
    {
        id: "1",
        degree: "Bachelor of Science in Software Engineering",
        school: "Sam Houston State University",
        location: "Huntsville, TX",
        period: "Expected Graduation: May 2025",
        gpa: "3.8/4.0",
        relevantCoursework: [
            "Data Structures & Algorithms",
            "Database Systems",
            "Software Design & Architecture",
            "Web Development",
            "Operating Systems",
        ],
    },
]

export function Education() {
    return (
        <section className="py-20">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold tracking-tight mb-12 text-center">Education</h2>
                <div className="max-w-3xl mx-auto">
                    {education.map((edu) => (
                        <Card key={edu.id} className="mb-8">
                            <CardHeader>
                                <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                                    <div>
                                        <CardTitle className="text-xl font-bold">{edu.school}</CardTitle>
                                        <div className="text-lg text-primary mt-1">{edu.degree}</div>
                                    </div>
                                    <div className="text-right">
                                        <span className="block text-sm font-medium">{edu.period}</span>
                                        <span className="block text-sm text-muted-foreground">{edu.location}</span>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="mb-4">
                                    <span className="font-semibold">GPA:</span> {edu.gpa}
                                </div>
                                <div>
                                    <h4 className="font-semibold mb-2">Relevant Coursework:</h4>
                                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 list-disc list-inside text-muted-foreground">
                                        {edu.relevantCoursework.map((course) => (
                                            <li key={course}>{course}</li>
                                        ))}
                                    </ul>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </section>
    )
}
