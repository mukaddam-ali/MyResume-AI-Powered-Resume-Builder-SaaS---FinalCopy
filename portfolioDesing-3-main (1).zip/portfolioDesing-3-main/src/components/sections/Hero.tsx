"use client"

import Link from "next/link"
import { ArrowRight, Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

export function Hero() {
    return (
        <section className="relative flex min-h-screen items-center justify-center overflow-hidden pt-16 px-4">
            {/* Background gradients */}
            <div className="absolute top-[-20%] right-[-10%] h-[500px] w-[500px] rounded-full bg-primary/20 blur-[100px]" />
            <div className="absolute bottom-[-20%] left-[-10%] h-[500px] w-[500px] rounded-full bg-purple-500/20 blur-[100px]" />

            <div className="container relative z-10 mx-auto max-w-5xl text-center">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <h2 className="mb-4 text-sm font-medium uppercase tracking-wider text-muted-foreground">
                        Software Engineer
                    </h2>
                    <h1 className="mb-6 text-5xl font-extrabold tracking-tight sm:text-7xl">
                        Hi, I&apos;m{" "}
                        <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">
                            Ali Mukaddam
                        </span>
                    </h1>
                    <p className="mb-8 mx-auto max-w-2xl text-xl text-muted-foreground">
                        A software engineering student passionate about building scalable web applications
                        and solving complex problems with modern technologies.
                    </p>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className="flex flex-col items-center justify-center gap-4 sm:flex-row"
                >
                    <Button asChild size="lg" className="min-w-[160px]">
                        <Link href="#projects">
                            View Projects <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                    </Button>
                    <Button asChild variant="outline" size="lg" className="min-w-[160px]">
                        <Link href="#contact">Contact Me</Link>
                    </Button>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.4 }}
                    className="mt-12 flex justify-center gap-6"
                >
                    <Link href="https://github.com/mukaddam-ali" target="_blank" className="text-muted-foreground hover:text-primary transition-colors">
                        <Github className="h-6 w-6" />
                        <span className="sr-only">GitHub</span>
                    </Link>
                    <Link href="https://linkedin.com/in/mukaddam-ali" target="_blank" className="text-muted-foreground hover:text-primary transition-colors">
                        <Linkedin className="h-6 w-6" />
                        <span className="sr-only">LinkedIn</span>
                    </Link>
                    <Link href="mailto:contact@alimukaddam.com" className="text-muted-foreground hover:text-primary transition-colors">
                        <Mail className="h-6 w-6" />
                        <span className="sr-only">Email</span>
                    </Link>
                </motion.div>
            </div>
        </section>
    )
}
