"use client"

import Image from "next/image"
import Link from "next/link"
import { Github } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface Project {
    id: string
    title: string
    description: string
    technologies: string[]
    githubUrl: string
    liveUrl?: string
    imageUrl: string
    category: string
}

interface ProjectCardProps {
    project: Project
}

export function ProjectCard({ project }: ProjectCardProps) {
    return (
        <Card className="group overflow-hidden border-border/50 bg-card transition-all hover:border-primary/50 hover:shadow-md">
            <div className="relative aspect-video overflow-hidden">
                {/* Placeholder image logic if no real image */}
                <div className="absolute inset-0 bg-muted/50 flex items-center justify-center text-muted-foreground">
                    {project.imageUrl ? (
                        <Image
                            src={project.imageUrl}
                            alt={project.title}
                            fill
                            className="object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                    ) : (
                        <span>No Image</span>
                    )}
                </div>
            </div>
            <CardHeader>
                <div className="flex justify-between items-start">
                    <CardTitle className="text-xl font-bold">{project.title}</CardTitle>
                    <Badge variant="secondary">{project.category}</Badge>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2">{project.description}</p>
            </CardHeader>
            <CardContent>
                <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                        <Badge key={tech} variant="outline" className="text-xs">
                            {tech}
                        </Badge>
                    ))}
                </div>
            </CardContent>
            <CardFooter className="gap-2">
                <Button asChild variant="outline" size="sm" className="w-full">
                    <Link href="https://github.com/mukaddam-ali" target="_blank">
                        <Github className="mr-2 h-4 w-4" /> Code
                    </Link>
                </Button>
            </CardFooter>
        </Card>
    )
}
