"use client"

import { SkillBar } from "@/components/ui/SkillBar"



const skills = {
    Frontend: [
        { name: "React / Next.js", level: 90 },
        { name: "TypeScript", level: 85 },
        { name: "Tailwind CSS", level: 95 },
    ],
    Backend: [
        { name: "Node.js", level: 80 },
        { name: "Python", level: 75 },
        { name: "PostgreSQL", level: 70 },
    ],
    DevOps: [
        { name: "Docker", level: 65 },
        { name: "AWS", level: 60 },
        { name: "Git / CI/CD", level: 85 },
    ],
}

export function Skills() {
    return (
        <section id="skills" className="py-20">
            <div className="container mx-auto px-4">
                <div className="text-center mb-12">
                    <h2 className="text-3xl font-bold tracking-tight mb-4">Technical Skills</h2>
                    <div className="w-20 h-1 bg-primary rounded-full mx-auto" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {Object.entries(skills).map(([category, items]) => (
                        <div key={category} className="p-6 rounded-lg border bg-card">
                            <h3 className="text-xl font-bold mb-6 text-center">{category}</h3>
                            <div className="space-y-4">
                                {items.map((skill) => (
                                    <SkillBar key={skill.name} name={skill.name} level={skill.level} />
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    )
}
