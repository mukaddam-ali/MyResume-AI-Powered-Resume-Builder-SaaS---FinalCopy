"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const experiences = [
    {
        id: "1",
        title: "Software Engineering Intern",
        company: "Tech Solutions Inc.",
        location: "Houston, TX",
        period: "May 2024 - Aug 2024",
        description: "Developed and maintained full-stack internal tools. Optimized database queries reducing load times by 40%.",
        technologies: ["React", "Node.js", "PostgreSQL", "Docker"],
    },
    {
        id: "2",
        title: "Freelance Front-End Developer",
        company: "Self-Employed",
        location: "Remote",
        period: "Jan 2023 - Present",
        description: "Building responsive websites for local businesses using modern web technologies.",
        technologies: ["Next.js", "Tailwind CSS", "Framer Motion"],
    },
]

export function Experience() {
    return (
        <section id="experience" className="py-20 bg-muted/30">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold tracking-tight mb-12 text-center">Experience</h2>
                <div className="max-w-3xl mx-auto space-y-8">
                    {experiences.map((exp) => (
                        <div key={exp.id} className="relative pl-8 border-l-2 border-primary/30 last:border-0">
                            <div className="absolute top-0 left-[-9px] w-4 h-4 rounded-full bg-primary ring-4 ring-background" />
                            <Card className="border-none shadow-none bg-transparent">
                                <CardHeader className="p-0 pb-2">
                                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-1">
                                        <CardTitle className="text-xl font-bold">{exp.title}</CardTitle>
                                        <span className="text-sm text-muted-foreground bg-secondary px-2 py-1 rounded">
                                            {exp.period}
                                        </span>
                                    </div>
                                    <div className="text-lg font-medium text-primary">{exp.company}</div>
                                </CardHeader>
                                <CardContent className="p-0">
                                    <p className="mb-4 text-muted-foreground">{exp.description}</p>
                                    <div className="flex flex-wrap gap-2">
                                        {exp.technologies.map((tech) => (
                                            <Badge key={tech} variant="outline" className="text-xs">
                                                {tech}
                                            </Badge>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    )
}
