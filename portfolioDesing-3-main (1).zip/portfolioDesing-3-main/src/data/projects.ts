export interface Project {
    id: string
    title: string
    description: string
    technologies: string[]
    githubUrl: string
    liveUrl?: string
    imageUrl: string
    category: string
}

export const projects: Project[] = [
    {
        id: "1",
        title: "E-Commerce Platform",
        description: "A full-featured e-commerce platform with cart, checkout, and admin dashboard.",
        technologies: ["Next.js", "TypeScript", "Prisma", "Stripe"],
        githubUrl: "https://github.com/mukaddam-ali/ecommerce",
        liveUrl: "https://ecommerce-demo.vercel.app",
        imageUrl: "",
        category: "Full Stack",
    },
    {
        id: "2",
        title: "Task Master",
        description: "A collaborative task management application with real-time updates.",
        technologies: ["React", "Firebase", "Tailwind CSS"],
        githubUrl: "https://github.com/mukaddam-ali/task-master",
        imageUrl: "",
        category: "Frontend",
    },
    {
        id: "3",
        title: "Weather Dashboard",
        description: "Real-time weather data visualization using OpenWeatherMap API.",
        technologies: ["Next.js", "Chart.js", "API Integration"],
        githubUrl: "https://github.com/mukaddam-ali/weather-dash",
        imageUrl: "",
        category: "Frontend",
    },
    {
        id: "4",
        title: "API Gateway Service",
        description: "High-performance API gateway with rate limiting and authentication.",
        technologies: ["Node.js", "Express", "Redis", "Docker"],
        githubUrl: "https://github.com/mukaddam-ali/api-gateway",
        imageUrl: "",
        category: "Backend",
    },
    {
        id: "5",
        title: "AI Image Generator",
        description: "Generate images from text prompts using OpenAI's DALL-E API.",
        technologies: ["Python", "Flask", "React", "OpenAI"],
        githubUrl: "https://github.com/mukaddam-ali/ai-gen",
        imageUrl: "",
        category: "AI/ML",
    }
];
