"use client"

import * as React from "react"
import Link from "next/link"
import Image from "next/image"
import { cn } from "@/lib/utils"
import { ThemeToggle } from "@/components/ui/ThemeToggle"
import { Menu } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"

const navItems = [
    { name: "Projects", href: "#projects" },
    { name: "Skills", href: "#skills" },
    { name: "Experience", href: "#experience" },
    { name: "Contact", href: "#contact" },
]

export function Header() {
    const [isScrolled, setIsScrolled] = React.useState(false)

    React.useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50)
        }
        window.addEventListener("scroll", handleScroll)
        return () => window.removeEventListener("scroll", handleScroll)
    }, [])

    return (
        <header
            className={cn(
                "fixed top-0 z-50 w-full border-b transition-colors duration-300 pr-[var(--removed-body-scroll-bar-size,0px)]",
                isScrolled
                    ? "border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
                    : "border-transparent bg-transparent"
            )}
        >
            <div className="container mx-auto px-4 flex h-16 items-center justify-between">
                <div className="mr-4 hidden md:flex">
                    <Link href="/" className="mr-6 flex items-center space-x-2">
                        <div className="relative h-14 w-14">
                            <Image
                                src={process.env.NODE_ENV === "production" ? "/portfolioDesing-3/Logo.jpeg" : "/Logo.jpeg"}
                                alt="Ali Mukaddam"
                                fill
                                className="object-contain"
                                priority
                            />
                        </div>
                    </Link>
                    <nav className="flex items-center space-x-6 text-sm font-medium">
                        {navItems.map((item) => (
                            <Link
                                key={item.href}
                                href={item.href}
                                className="transition-colors hover:text-foreground/80 text-foreground/60"
                            >
                                {item.name}
                            </Link>
                        ))}
                    </nav>
                </div>

                {/* Mobile View - Logo on Left */}
                <div className="md:hidden flex items-center">
                    <Link href="/" className="mr-6 flex items-center space-x-2">
                        <div className="relative h-14 w-14">
                            <Image
                                src={process.env.NODE_ENV === "production" ? "/portfolioDesing-3/Logo.jpeg" : "/Logo.jpeg"}
                                alt="Ali Mukaddam"
                                fill
                                className="object-contain"
                                priority
                            />
                        </div>
                    </Link>
                </div>

                <div className="flex items-center justify-end space-x-4">
                    <ThemeToggle />
                    {/* Mobile Menu */}
                    <Sheet>
                        <SheetTrigger asChild>
                            <Button variant="ghost" size="icon" className="md:hidden">
                                <Menu className="h-5 w-5" />
                                <span className="sr-only">Toggle Menu</span>
                            </Button>
                        </SheetTrigger>
                        <SheetContent side="right">
                            <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
                            <div className="flex flex-col space-y-4 mt-8">
                                {navItems.map((item) => (
                                    <Link
                                        key={item.href}
                                        href={item.href}
                                        className="text-lg font-medium text-foreground/60 hover:text-foreground"
                                    >
                                        {item.name}
                                    </Link>
                                ))}
                            </div>
                        </SheetContent>
                    </Sheet>
                </div>
            </div>
        </header>
    )
}
